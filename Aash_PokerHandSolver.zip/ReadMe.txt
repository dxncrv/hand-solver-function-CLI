This zip contains a C# console app running on .NET 7.0 framework.
May require .NET SDK to run the app on terminal if using VS Code.

Script location:
app/PokerSolver.cs

Executable location:
app/bin/Debug/net7.0/app.exe

Thanks you!